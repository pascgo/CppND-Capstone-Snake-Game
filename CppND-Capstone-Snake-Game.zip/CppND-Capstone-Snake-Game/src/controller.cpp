#include "controller.h"
#include <iostream>
#include "SDL.h"
#include "snake.h"

// Controller to update the snake's direction based on the input
void Controller::ChangeDirection(Snake &snake, Snake::Direction NewInput) const {
  // Checking if snake's direction is new 
  // whatever its size and opposite direction  
  //
  Snake::Direction CurrentInput = snake.GetDirection();
  if (CurrentInput != NewInput){
      snake.SetDirection(NewInput);
      std::cout << "Change direction \n";
  }
  return;
}

// Controller to handle keyboard input using the SDL 
void Controller::HandleInput(bool &running, Snake &snake) const {
  SDL_Event e;
  while (SDL_PollEvent(&e)) {
    if (e.type == SDL_QUIT) {
      running = false;
    } else if (e.type == SDL_KEYDOWN) {
      // key is pressed look for which one  
      switch (e.key.keysym.sym) {
        // Request to change the direction of the snake to go Up
        case SDLK_UP:
          ChangeDirection(snake, Snake::Direction::kUp);
          break;
        // Request to change the direction of the snake to go Down
        case SDLK_DOWN:
          ChangeDirection(snake, Snake::Direction::kDown);
          break;
        // Request to change the direction of the snake to go left
        case SDLK_LEFT:
          ChangeDirection(snake, Snake::Direction::kLeft);
          break;
        // Request to change the direction of the snake to go right
        case SDLK_RIGHT:
          ChangeDirection(snake, Snake::Direction::kRight);
          break;
      }
    }
  }
}