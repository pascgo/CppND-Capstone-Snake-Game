#ifndef CONTROLLER_H
#define CONTROLLER_H

#include "snake.h"

class Controller {
 public:
 // Controller to handle keyboard input using the SDL  - a read-only function -
  void HandleInput(bool &running, Snake &snake) const;

 private:
 // Controller to update the snake's direction based on the input - a read-only function -
  void ChangeDirection(Snake &snake, Snake::Direction input) const;
};

#endif