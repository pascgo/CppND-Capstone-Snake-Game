#ifndef BOARD_H
#define BOARD_H

#include <vector>     // To read board file 
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>


using std::vector;                     
using std::string;
using std::cout;
using std::ifstream;
using std::ofstream;
using std::ios;
using std::string;
using std::vector;

enum State {kEmpty, kObstacle};


#endif