#ifndef SNAKE_H
#define SNAKE_H

#include <vector>
#include "SDL.h"

class Snake {
 public:
  // Snake's direction  
  enum class Direction { kUp, kDown, kLeft, kRight, kNull };

  // Snake grid constructor 
  Snake(int grid_width, int grid_height)
      : grid_width(grid_width),
        grid_height(grid_height),
        _head_x(grid_width/2),
        _head_y(grid_height/2) {}

  // Method to update the snake's path
  void Update();

   // Method to grow-up the snake's body
  void GrowBody();
  // Method to read if  a part of the snake is in cell x,y
  bool IsSnakeInCell(int x, int y);

  // Getters and Setters 
  
    // Mehod to read the snake's direction
  Direction GetDirection(){return _direction;}

  // Mehod to update the snake's direction
  Direction SetDirection(Direction NewDirection){
   _direction = NewDirection;
  }
 
   // Mehod to read the snake's x-position
  float GetHeadPosX() const { return _head_x;}
   // Mehod to read the snake's y-position
  float GetHeadPosY() const { return _head_y;}
  // Mehod to read the snake's speed
  float GetSpeed() const { return _speed;}

   // Mehod to read the snake's status
  float IsAlive() const { return _alive;}

  // Mehod to read the snake's size
  int GetSize() const { return _size;}

  // Mehod to read the snake's body
  std::vector<SDL_Point> GetBody() const { return _body;}


  // Mehod to increase the snake's speed
  void IncreaseSpeed(float Increm){
   _speed+=Increm;
  }

  

 private:
  Direction _direction{Direction::kUp}; // object's direction
  float _speed{0.1f};                      // Object's speed
  float _head_x;                        // Object's position
  float _head_y;                        // no initialization here
  bool _alive{true};                    // Object's status
  int _size{1};                         // Object's size 
  std::vector<SDL_Point> _body;         // Object's body

  void UpdateHead();
  void UpdateBody(SDL_Point &current_cell, SDL_Point &prev_cell);

  bool growing{false};
  int grid_width;
  int grid_height;
};

#endif