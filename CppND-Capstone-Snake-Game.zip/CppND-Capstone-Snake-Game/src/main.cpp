#include <iostream>
#include "controller.h"
#include "game.h"
#include "renderer.h"
#include "board.h"      // For future needs
#include <fstream>
#include <string>

using std::cout;
using std::string;
using std::ifstream;
using std::ofstream;
using std::ios;


#include <vector>       // To read board file
using std::size_t;       
using std::vector;      
using std::string;

#ifndef DEBUG_GAME
// ACTIVATION DEBUG_GAME for debugging mode 
//define DEBUG_GAME
#endif

#ifndef DEBUG_GAME
// Constant initialization 
#define K_FRAME_PER_SEC 60                          // normal speed for key-frames per second
#else
// Initialization for Debugging
#define K_FRAME_PER_SEC 10                         // slow speed for key-frames per second
#endif

// Initialization of the cell-grid for the game 
#define K_SCREEN_PIXELS     640                    // Fixed Square screen 
#define K_GRID_CELL_PIXELS   32                    // Fixed Square Grid cell 


// Initialization for file
#define K_PATH        "../src/"
#define K_FILE    "2.ScoreGame"


int main() {

  // Constant expressions useful for the rest of the game
  constexpr size_t kFramesPerSecond{K_FRAME_PER_SEC};      // key-frames per second
  constexpr size_t kMsPerFrame{1000 / kFramesPerSecond};   // milliseconds per frame
  constexpr size_t kScreenWidth{K_SCREEN_PIXELS};          // Fixed Screen Width (horizontal), in pixel
  constexpr size_t kScreenHeight{K_SCREEN_PIXELS};         // Fixed Screen Height (vertical), in pixel
  constexpr size_t kGridWidth{K_SCREEN_PIXELS/K_GRID_CELL_PIXELS};   // Grid Width 
  constexpr size_t kGridHeight{K_SCREEN_PIXELS/K_GRID_CELL_PIXELS};  // Grid Height

  // Creation of a renderer object with the screen and the grid size 
  Renderer renderer(kScreenWidth, kScreenHeight, kGridWidth, kGridHeight);
  // Creation of a controller object
  Controller controller;
  // Creation of a game object with the grid size 
  Game game(kGridWidth, kGridHeight);

  // Display on screen the welcome from file
  string path=K_PATH;
  string filename = K_FILE;
  ifstream myfile (path+filename);          // Intput file stream 
  if (myfile) {
    string line;                        
    while (getline(myfile, line)) {     // Read lines
      std::cout << line << "\n";        // Output lines on screen
    }
  }else{
    std::cout << " ** FILE NOT FOUND ** \n";
  }
  myfile.close(); 

  // Start the game loop with controller, renderer and key-frame per second
  game.Run(controller, renderer, kMsPerFrame);

  // Printout at the end of the game
  std::cout << "Game has terminated successfully!\n";
  // Print the score once the game is done
  std::cout << "Score: " << game.GetScore() << "\n";
  // Print the size of the snake once the game is done
  std::cout << "Size: " << game.GetSize() << "\n";
 
  // Save score onto file 
  ofstream myfile2(path+filename, ios::app);  // Output file stream 
  // Add the line in a text file 
  myfile2 << " Previous Score  :" << game.GetScore() << "\n"; 
  myfile2.close();                   // Close myfile

 return 0;
}