#include "snake.h"
#include <cmath>
#include <iostream>

void Snake::Update() {
  SDL_Point prev_cell{
      static_cast<int>(_head_x),
      static_cast<int>(_head_y)};  // We first capture the head's cell before updating.
  UpdateHead();
  SDL_Point current_cell{
      static_cast<int>(_head_x),
      static_cast<int>(_head_y)};  // Capture the head's cell after updating.

  // Update all of the body vector items if the snake head has moved to a new
  // cell.
  if (current_cell.x != prev_cell.x || current_cell.y != prev_cell.y) {
    UpdateBody(current_cell, prev_cell);
  }
}

// Method to update the head location using the snake's speed 
void Snake::UpdateHead() {

  // Get current Snake's speed 
  float SnakeSpeed = Snake::GetSpeed();

// Update coordinates according the snake's direction 
  switch (Snake::GetDirection()) {
    case Direction::kUp:
    // Move head UP by decreasing y-coordinate
      _head_y -= SnakeSpeed;
      break;
    // Move head UP by increasing y-coordinate
    case Direction::kDown:
      _head_y += SnakeSpeed;
      break;
    // Move head Left by decreasing x-coordinate
    case Direction::kLeft:
      _head_x -= SnakeSpeed;
    //  Codedir=3;
      break;
    // Move head Right by increasing x-coordinate
    case Direction::kRight:
      _head_x += SnakeSpeed;
      break;
  }

  // Wrap the Snake around to the beginning if going off of the screen.
  _head_x = fmod(_head_x + grid_width, grid_width);
  _head_y = fmod(_head_y + grid_height, grid_height);
}

void Snake::UpdateBody(SDL_Point &current_head_cell, SDL_Point &prev_head_cell) {
  // Add previous head location to vector
  _body.push_back(prev_head_cell);

  if (!growing) {
    // Remove the tail from the vector.
    _body.erase(_body.begin());
  } else {
    growing = false;
    _size++;
  }

  // Check if the snake has died.
  for (auto const &item : _body) {
    if (current_head_cell.x == item.x && current_head_cell.y == item.y) {
      _alive = false;
    }
  }
}

void Snake::GrowBody() { growing = true; }

// Inefficient method to check if cell is occupied by snake.
bool Snake::IsSnakeInCell(int x, int y) {

  int head_x;
  int head_y;

  head_x=static_cast<int>(_head_x);
  head_y=static_cast<int>(_head_y);
  // Ckeck if the new cell x,y is the cell occupied by the head 
  if ((x == head_x) && (y == head_y)) {
    std::cout << " OCCUPIED BY SNAKE !! \n";
        return true;
  }

  // Ckeck if the new cell x,y is a cell occupied by the body
  for (auto const &item : _body) {
     std::cout << "BODY POSITION IS :"<< item.x << " , "<< item.y << "\n";
    if (x == item.x && y == item.y) {
      return true;
    }
  }
  return false;
}